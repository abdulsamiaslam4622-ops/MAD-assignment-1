import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function OrderCard({ order }) {
  return (
    <View style={styles.card}>
      <Text style={styles.name}>{order.name}</Text>
      <Text style={styles.details}>Quantity: {order.quantity}</Text>
      <Text style={styles.details}>Total: ${order.price * order.quantity}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  name: { fontSize: 20, fontWeight: 'bold', color: '#8B0000' },
  details: { fontSize: 16, color: '#333' },
});