// services/api.js

export const mockMenu = [
  { id: 1, name: 'Margherita Pizza', price: 12 },
  { id: 2, name: 'Veg Burger', price: 8 },
  { id: 3, name: 'Pasta Alfredo', price: 10 },
];

export const mockOrders = [];
export const mockFeedbacks = [];
export const recentActivities = [];

// --- REALISTIC TABLE TRACKING ---
export const tables = [
  { id: '1', status: 'Available' },
  { id: '2', status: 'Occupied' }, // Someone is already there
  { id: '3', status: 'Available' },
  { id: '4', status: 'Available' },
  { id: '5', status: 'Occupied' },
  { id: '6', status: 'Available' },
  { id: '7', status: 'Available' },
  { id: '8', status: 'Available' },
  { id: '9', status: 'Available' },
  { id: '10', status: 'Available' },
];

export const logActivity = (action) => {
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  recentActivities.unshift({ id: Date.now().toString(), action, time: timestamp });
};

export const loginUser = (email, password) => {
  if (email === 'user@test.com' && password === '1234') {
    logActivity('User logged in'); 
    return { name: 'Test User', email };
  } else return null;
};