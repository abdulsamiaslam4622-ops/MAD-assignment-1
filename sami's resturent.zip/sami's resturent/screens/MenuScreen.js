import React, { useState } from 'react';
import { View, FlatList, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { mockMenu } from '../services/api';
import MenuItemCard from '../components/MenuItemCard';

export default function MenuScreen({ navigation }) {
  const [menuItems] = useState(mockMenu);

  const handleOrder = (item) => navigation.navigate('Order', { item });

  return (
    <View style={styles.container}>
      <FlatList
        data={menuItems}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => <MenuItemCard item={item} onOrder={handleOrder} />}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Reservation')}>
        <Text style={styles.buttonText}>Reserve Table</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('TableScan')}>
        <Text style={styles.buttonText}>Scan Table QR</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Feedback')}>
        <Text style={styles.buttonText}>Feedback</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#FFF5F5' },
  button: {
    backgroundColor: '#8B0000',
    paddingVertical: 15,
    borderRadius: 12,
    marginVertical: 8,
    alignItems: 'center',
  },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});