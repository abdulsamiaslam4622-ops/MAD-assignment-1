import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';

export default function TableScanScreen() {
  const [scannedTable, setScannedTable] = useState(null);

  // Same occupied tables as reservation screen
  const occupiedTables = [2, 5, 8];

  const handleScan = () => {
    const randomTable = Math.floor(Math.random() * 10) + 1;

    setScannedTable(randomTable);

    if (occupiedTables.includes(randomTable)) {
      Alert.alert(
        'Table Occupied',
        `Table ${randomTable} is currently occupied. Please try another table.`
      );
    } else {
      Alert.alert(
        'Scan Successful',
        `You are seated at Table ${randomTable}`
      );
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Scan Table QR</Text>

      {/* Fake QR Scanner Box */}
      <View style={styles.qrBox}>
        <Text style={styles.qrText}>QR Scanner Area</Text>
      </View>

      {scannedTable && (
        <View style={styles.resultCard}>
          <Text style={styles.resultText}>
            Scanned Table: {scannedTable}
          </Text>
          <Text
            style={[
              styles.statusText,
              occupiedTables.includes(scannedTable)
                ? styles.occupied
                : styles.available,
            ]}
          >
            {occupiedTables.includes(scannedTable)
              ? 'Occupied'
              : 'Available'}
          </Text>
        </View>
      )}

      <TouchableOpacity style={styles.button} onPress={handleScan}>
        <Text style={styles.buttonText}>Scan QR Code</Text>
      </TouchableOpacity>

      {scannedTable && (
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#555' }]}
          onPress={() => setScannedTable(null)}
        >
          <Text style={styles.buttonText}>Scan Again</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF5F5',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 30,
  },
  qrBox: {
    width: 220,
    height: 220,
    borderWidth: 3,
    borderColor: '#8B0000',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
    backgroundColor: '#fff',
  },
  qrText: {
    color: '#888',
  },
  resultCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20,
    width: '80%',
    elevation: 4,
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  statusText: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  available: {
    color: 'green',
  },
  occupied: {
    color: 'red',
  },
  button: {
    backgroundColor: '#8B0000',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 12,
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});