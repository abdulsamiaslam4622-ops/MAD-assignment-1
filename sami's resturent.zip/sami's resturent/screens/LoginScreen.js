import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet } from 'react-native';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (email === 'sami' && password === '1') {
      navigation.navigate('Menu');
    } else {
      Alert.alert('Login Failed', 'Email or password incorrect');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🍽️ Sami's Resturent </Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        placeholderTextColor="#aaa"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
        placeholderTextColor="#aaa"
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 30, backgroundColor: '#FFF5F5' },
  title: { fontSize: 32, fontWeight: 'bold', color: '#8B0000', marginBottom: 40, textAlign: 'center' },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 20,
    padding: 15,
    borderRadius: 12,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#8B0000',
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});