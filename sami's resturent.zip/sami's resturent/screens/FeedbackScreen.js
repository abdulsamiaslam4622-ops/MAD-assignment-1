import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, FlatList } from 'react-native';
import { mockFeedbacks, logActivity } from '../services/api';

const COLORS = { 
  primary: '#8B0000', 
  secondary: '#FFF5F5', 
  card: '#FFFFFF', 
  text: '#333',
  border: '#DDD'
};

export default function FeedbackScreen() {
  const [feedback, setFeedback] = useState('');
  const [allFeedbacks, setAllFeedbacks] = useState([...mockFeedbacks]);

  const handleSubmit = () => {
    if (!feedback.trim()) {
      return Alert.alert('Error', 'Please write something before submitting.');
    }

    const newFeedback = {
      id: Date.now().toString(),
      text: feedback,
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    // Save to the global mock database
    mockFeedbacks.unshift(newFeedback);
    // Update local state to show it immediately
    setAllFeedbacks([newFeedback, ...allFeedbacks]);
    
    logActivity('Submitted feedback');
    Alert.alert('Thank you!', 'Your feedback has been saved.');
    setFeedback('');
  };

  const renderFeedbackItem = ({ item }) => (
    <View style={styles.feedbackCard}>
      <Text style={styles.feedbackText}>"{item.text}"</Text>
      <Text style={styles.feedbackDate}>{item.date}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Customer Feedback</Text>
      
      {/* Input Section */}
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Share your experience with us..."
          style={styles.input}
          multiline
          numberOfLines={4}
          value={feedback}
          onChangeText={setFeedback}
          placeholderTextColor="#999"
        />
        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>Post Feedback</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.divider} />

      {/* History Section */}
      <Text style={styles.historyTitle}>Previous Feedbacks ({allFeedbacks.length})</Text>
      <FlatList
        data={allFeedbacks}
        keyExtractor={(item) => item.id}
        renderItem={renderFeedbackItem}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={<Text style={styles.empty}>No feedback yet. Be the first!</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: COLORS.secondary },
  title: { fontSize: 26, fontWeight: 'bold', color: COLORS.primary, textAlign: 'center', marginTop: 20, marginBottom: 20 },
  inputContainer: { backgroundColor: '#fff', padding: 15, borderRadius: 15, elevation: 3 },
  input: { 
    fontSize: 16, 
    color: COLORS.text, 
    textAlignVertical: 'top', 
    minHeight: 100,
    marginBottom: 10 
  },
  button: { 
    backgroundColor: COLORS.primary, 
    paddingVertical: 12, 
    borderRadius: 10, 
    alignItems: 'center' 
  },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  divider: { height: 1, backgroundColor: COLORS.border, marginVertical: 25 },
  historyTitle: { fontSize: 18, fontWeight: 'bold', color: COLORS.primary, marginBottom: 15 },
  listContent: { paddingBottom: 30 },
  feedbackCard: { 
    backgroundColor: '#fff', 
    padding: 15, 
    borderRadius: 12, 
    marginBottom: 10, 
    borderLeftWidth: 5, 
    borderLeftColor: COLORS.primary,
    elevation: 1
  },
  feedbackText: { fontSize: 15, fontStyle: 'italic', color: COLORS.text },
  feedbackDate: { fontSize: 12, color: '#888', marginTop: 5, textAlign: 'right' },
  empty: { textAlign: 'center', color: '#999', marginTop: 20 }
});