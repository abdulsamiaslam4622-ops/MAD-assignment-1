import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Alert,
} from 'react-native';
import QRCode from 'react-native-qrcode-svg';

export default function PaymentScreen({ route, navigation }) {
  const { orders } = route.params;

  const [selectedMethod, setSelectedMethod] = useState(null);

  const total = orders.reduce(
    (sum, o) => sum + o.price * o.quantity,
    0
  );

  const paymentData = JSON.stringify({
    restaurant: "Sami's Restaurant",
    amount: total,
    method: selectedMethod,
  });

  const handleCashPayment = () => {
    Alert.alert(
      "Order Confirmed",
      "Your order will be paid in cash at delivery."
    );
    navigation.navigate('Menu');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Payment</Text>

      <FlatList
        data={orders}
        keyExtractor={(o) => o.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text>
              {item.quantity} x ${item.price}
            </Text>
          </View>
        )}
      />

      <Text style={styles.total}>Total: ${total}</Text>

      {/* PAYMENT METHODS */}
      <Text style={styles.sectionTitle}>Select Payment Method</Text>

      <TouchableOpacity
        style={[
          styles.methodButton,
          selectedMethod === 'EasyPaisa' && styles.selectedMethod,
        ]}
        onPress={() => setSelectedMethod('EasyPaisa')}
      >
        <Text style={styles.methodText}>EasyPaisa</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.methodButton,
          selectedMethod === 'JazzCash' && styles.selectedMethod,
        ]}
        onPress={() => setSelectedMethod('JazzCash')}
      >
        <Text style={styles.methodText}>JazzCash</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.methodButton,
          selectedMethod === 'Cash' && styles.selectedMethod,
        ]}
        onPress={() => setSelectedMethod('Cash')}
      >
        <Text style={styles.methodText}>Cash on Delivery</Text>
      </TouchableOpacity>

      {/* QR CODE FOR DIGITAL PAYMENTS */}
      {(selectedMethod === 'EasyPaisa' ||
        selectedMethod === 'JazzCash') && (
        <View style={styles.qrContainer}>
          <QRCode value={paymentData} size={180} />
          <Text style={styles.scanText}>
            Scan with {selectedMethod} App
          </Text>
        </View>
      )}

      {/* CASH CONFIRM BUTTON */}
      {selectedMethod === 'Cash' && (
        <TouchableOpacity
          style={styles.confirmButton}
          onPress={handleCashPayment}
        >
          <Text style={styles.confirmText}>
            Confirm Cash Order
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFF5F5',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B0000',
    textAlign: 'center',
    marginBottom: 15,
  },
  card: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 10,
    marginBottom: 8,
  },
  itemName: {
    fontWeight: 'bold',
  },
  total: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 15,
    color: '#8B0000',
    textAlign: 'center',
  },
  sectionTitle: {
    fontWeight: 'bold',
    marginBottom: 10,
  },
  methodButton: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  selectedMethod: {
    borderColor: '#8B0000',
    borderWidth: 2,
  },
  methodText: {
    fontWeight: 'bold',
  },
  qrContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
    marginTop: 15,
  },
  scanText: {
    marginTop: 10,
    fontWeight: 'bold',
  },
  confirmButton: {
    backgroundColor: '#8B0000',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 15,
  },
  confirmText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});