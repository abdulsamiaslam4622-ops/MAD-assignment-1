import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, Alert, StyleSheet, ScrollView, FlatList } from 'react-native';
import { tables, logActivity } from '../services/api';

const COLORS = { 
  primary: '#8B0000', 
  secondary: '#FFF5F5', 
  available: '#4CAF50', 
  occupied: '#D32F2F',
  selected: '#FF9800',
  text: '#333' 
};

export default function ReservationScreen() {
  const [name, setName] = useState('');
  const [selectedTable, setSelectedTable] = useState(null);

  const handleReserve = () => {
    if (!name || !selectedTable) {
      return Alert.alert('Missing Info', 'Please enter your name and select a table.');
    }

    const tableIndex = tables.findIndex(t => t.id === selectedTable);
    
    if (tables[tableIndex].status === 'Occupied') {
      return Alert.alert('Error', 'This table is already occupied!');
    }

    // Update table status locally for this session
    tables[tableIndex].status = 'Occupied';
    
    logActivity(`Reserved Table ${selectedTable} for ${name}`);
    Alert.alert('Success', `Table ${selectedTable} is now reserved for you!`);
    
    setName('');
    setSelectedTable(null);
  };

  const renderTable = ({ item }) => {
    const isOccupied = item.status === 'Occupied';
    const isSelected = selectedTable === item.id;

    return (
      <TouchableOpacity 
        style={[
          styles.tableBox, 
          isOccupied ? styles.tableOccupied : styles.tableAvailable,
          isSelected && styles.tableSelected
        ]}
        onPress={() => !isOccupied && setSelectedTable(item.id)}
        disabled={isOccupied}
      >
        <Text style={styles.tableText}>T-{item.id}</Text>
        <Text style={styles.statusText}>{item.status}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Table Reservation</Text>
      
      <Text style={styles.sectionTitle}>Select a Table:</Text>
      <FlatList
        data={tables}
        renderItem={renderTable}
        keyExtractor={item => item.id}
        numColumns={3}
        scrollEnabled={false}
        contentContainerStyle={styles.grid}
      />

      <View style={styles.form}>
        <Text style={styles.label}>Your Name</Text>
        <TextInput 
          style={styles.input}
          placeholder="Enter name for reservation"
          value={name}
          onChangeText={setName}
        />
        
        {selectedTable && (
          <Text style={styles.selectionInfo}>You have selected: <Text style={{fontWeight: 'bold'}}>Table {selectedTable}</Text></Text>
        )}

        <TouchableOpacity style={styles.button} onPress={handleReserve}>
          <Text style={styles.buttonText}>Confirm Booking</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.secondary, padding: 20 },
  title: { fontSize: 26, fontWeight: 'bold', color: COLORS.primary, textAlign: 'center', marginVertical: 20 },
  sectionTitle: { fontSize: 18, fontWeight: '600', marginBottom: 15 },
  grid: { alignItems: 'center' },
  tableBox: {
    width: 90,
    height: 80,
    margin: 8,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent'
  },
  tableAvailable: { backgroundColor: '#E8F5E9', borderColor: COLORS.available },
  tableOccupied: { backgroundColor: '#FFEBEE', borderColor: COLORS.occupied, opacity: 0.6 },
  tableSelected: { borderColor: COLORS.selected, borderWidth: 3 },
  tableText: { fontWeight: 'bold', fontSize: 16 },
  statusText: { fontSize: 10, textTransform: 'uppercase' },
  form: { marginTop: 30, paddingBottom: 50 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 5 },
  input: { backgroundColor: '#fff', padding: 15, borderRadius: 10, borderWidth: 1, borderColor: '#ddd' },
  selectionInfo: { marginVertical: 15, color: COLORS.primary },
  button: { backgroundColor: COLORS.primary, padding: 18, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});