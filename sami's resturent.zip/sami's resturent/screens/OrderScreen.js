import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import OrderCard from '../components/OrderCard';

export default function OrderScreen({ route, navigation }) {
  const { item } = route.params;

  const [orders, setOrders] = useState([]);

  const addToOrder = () => {
    const existing = orders.find(o => o.id === item.id);

    if (existing) {
      const updatedOrders = orders.map(o =>
        o.id === item.id ? { ...o, quantity: o.quantity + 1 } : o
      );
      setOrders(updatedOrders);
    } else {
      setOrders([...orders, { ...item, quantity: 1 }]);
    }

    Alert.alert('Added to Order');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Order</Text>

      {orders.length === 0 ? (
        <Text style={{ textAlign: 'center', marginBottom: 20 }}>
          No items added yet
        </Text>
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(o) => o.id.toString()}
          renderItem={({ item }) => <OrderCard order={item} />}
        />
      )}

      <TouchableOpacity style={styles.button} onPress={addToOrder}>
        <Text style={styles.buttonText}>Add Item</Text>
      </TouchableOpacity>

      {orders.length > 0 && (
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Payment', { orders })}
        >
          <Text style={styles.buttonText}>Proceed to Payment</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#FFF5F5' },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 20,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#8B0000',
    paddingVertical: 15,
    borderRadius: 12,
    marginVertical: 10,
    alignItems: 'center',
  },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});