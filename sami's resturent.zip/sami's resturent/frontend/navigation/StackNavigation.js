import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from '../../screens/LoginScreen';
import MenuScreen from '../../screens/MenuScreen';
import OrderScreen from '../../screens/OrderScreen';
import ReservationScreen from '../../screens/ReservationScreen';
import PaymentScreen from '../../screens/PaymentScreen';
import FeedbackScreen from '../../screens/FeedbackScreen';
import TableScanScreen from '../../screens/TableScanScreen';

const Stack = createNativeStackNavigator();

export default function StackNavigation() {
  return (
    <Stack.Navigator initialRouteName="Login">
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Menu" component={MenuScreen} />
      <Stack.Screen name="Order" component={OrderScreen} />
      <Stack.Screen name="Reservation" component={ReservationScreen} />
      <Stack.Screen name="Payment" component={PaymentScreen} />
      <Stack.Screen name="Feedback" component={FeedbackScreen} />
      <Stack.Screen name="TableScan" component={TableScanScreen} />
    </Stack.Navigator>
  );
}